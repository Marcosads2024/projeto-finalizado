requestMain('main.html') // Nome da página
  .then(() => {
    // Pego o botao aqui pq preciso aguardar tela main carregar
    const photoBtnElement = document.querySelector('.photo-btn');
    const navBtnElements = document.querySelectorAll('.nav-container');

    if (photoBtnElement) {
      const createCard = (imgUrl) => {
        const div = document.createElement('div');
        const img = document.createElement('img');
        const h1 = document.createElement('h1');
        const p = document.createElement('p');

        div.classList.add('card');
        img.src = imgUrl;
        img.classList.add('photo');
        h1.innerText = 'The Doors';
        h1.classList.add('title');
        p.innerText = 'Banda da década de 70';
        p.classList.add('text-content');

        div.appendChild(img);
        div.appendChild(h1);
        div.appendChild(p);
        return div;
      };

      photoBtnElement.addEventListener('click', () => {
        requestMain('photo.html').then(() => {
          const cardContainerElement =
            document.querySelector('.card-container');
          Array(4)
            .fill('')
            .forEach(() => {
              const cardElement = createCard(
                'https://i.pinimg.com/originals/70/e8/87/70e887d33441142b44719053603925f5.jpg',
              );
              cardContainerElement.appendChild(cardElement);
            });
        });
      });
    }

    if (navBtnElements) {
      const pages = ['main.html'];
      navBtnElements.forEach((btn, index) => {
        if (btn) {
          btn.addEventListener('click', () => {
            if (pages[index]) {
              // requestMain(pages[index]);
              window.location.href = '../index.html';
            }
          });
        }
      });
    }
  });
