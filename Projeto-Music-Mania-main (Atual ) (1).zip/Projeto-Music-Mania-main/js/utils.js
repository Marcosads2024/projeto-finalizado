const divElement = document.querySelector('.content');
const loadingElement = document.querySelector('.loading-message');

const requestMain = async (path) => {
  loadingElement.style.display = 'block';
  await fetch(`/pages/${path}`) // Recupera as informacoes da pagina html
    .then((response) => {
      // .then aguarda o retorno do fetch
      return response.text();
    })
    .then((data) => {
      // Inserir o conteúdo carregado do data na div
      divElement.innerHTML = data;
    })
    .catch((error) => {
      console.log('Erro ao carregar o HTML:', error);
    })
    .finally(() => {
      loadingElement.style.display = 'none';
    });
};
