# Projeto Music Mania

### Para rodar o projeto execute o comando abaixo no terminal:

```JS
npm install
npm run dev
```
